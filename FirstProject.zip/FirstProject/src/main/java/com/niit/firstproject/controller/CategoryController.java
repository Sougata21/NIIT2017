package com.niit.firstproject.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.firstproject.dao.CategoryDao;
import com.niit.firstproject.dao.ProductDao;
import com.niit.firstproject.dao.UsersDao;
import com.niit.firstproject.model.Category;
import com.niit.firstproject.model.Users;


@Controller
public class CategoryController {
	@Autowired 
	  CategoryDao categoryDao;
    @Autowired 
	 ProductDao productDao;
    
    @Autowired 
	  UsersDao usersDao;
	  
	
	@RequestMapping("/categoryform")  
    public ModelAndView showform(){  
        return new ModelAndView("categoryform","command",new Category());  //command data name request.setAttribute("commnad",new Users();
    } 
	@RequestMapping(value="/savecategory",method = RequestMethod.POST)  
    public ModelAndView save(@ModelAttribute("category") Category category){
		categoryDao.addCategory(category);
		
		return new ModelAndView("redirect:/viewcategory");
		
	} 
	@RequestMapping("/viewcategory")  
    public ModelAndView viewcategory(){  
        List<Category> list=categoryDao.list();
        return new ModelAndView("viewcategory","list",list);  //"list" requestattribeut name
    }  
   	
	 @RequestMapping(value="/editcategory/{id}")  
	    public ModelAndView edit(@PathVariable int id){  
	        Category category= categoryDao.getCategoryById(id);
	        return new ModelAndView("editcategoryform","command",category);  
	    }  
	    
	    
	    // It updates model object.   
	    @RequestMapping(value="/edit",method = RequestMethod.POST)  
	    public ModelAndView edit(@ModelAttribute("categoty")Category category){  
	    	categoryDao.updateCategory(category);
	        return new ModelAndView("redirect:/viewcategory");  
	    }  
	    
	     //It deletes record for the given id in URL and redirects to /viewusers   
	    @RequestMapping(value="/deletecategory/{id}",method = RequestMethod.GET)  
	    public ModelAndView delete(@PathVariable int id){ 
	    	System.out.println("delete is called");
	       categoryDao.deleteCategory(id);
	        return new ModelAndView("redirect:/viewcategory");  
	    }

 
@RequestMapping("/homepage")  
public ModelAndView index(HttpSession session){  
 ModelAndView mv= new ModelAndView("homepage");
 session.setAttribute("categoryList", categoryDao.list());
 mv.addObject("categoryList", categoryDao.list());
 
  return mv;
    		
}  
}   





