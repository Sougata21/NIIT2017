package com.niit.firstproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class Supplier {
	@Id
	@GeneratedValue
	@Column(name="supplierid")

	private int suupplierId;
	
	@NotEmpty(message = "Please give Description")
	private String supplierDescription;

	public int getSuupplierId() {
		return suupplierId;
	}

	public void setSuupplierId(int suupplierId) {
		this.suupplierId = suupplierId;
	}

	public String getSupplierDescription() {
		return supplierDescription;
	}

	public void setSupplierDescription(String supplierDescription) {
		this.supplierDescription = supplierDescription;
	}
	

	
}
