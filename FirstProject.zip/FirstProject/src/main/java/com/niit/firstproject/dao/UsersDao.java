package com.niit.firstproject.dao;

import java.util.List;

import com.niit.firstproject.model.Users;



public interface UsersDao {
	
	public void addUsers(Users users);
	public void updateUsers(Users users);
	public void deleteUsers(String userId);
	public Users getUsersById(String userId);
	public List<Users> getAllUsers();
	
    
	

}
