package com.niit.firstproject.controller;

import java.security.Principal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.firstproject.dao.BillDao;
import com.niit.firstproject.dao.CartItemDao;
import com.niit.firstproject.dao.UsersDao;
import com.niit.firstproject.model.Bill;
import com.niit.firstproject.model.CartItem;
import com.niit.firstproject.model.Users;

@Controller
public class BillController {
	@Autowired 
	 UsersDao usersDao;
	 @Autowired
	 BillDao billDao;
	 @Autowired
	 CartItemDao cartItemDao;
	 
	 @RequestMapping("/billform")
	 public ModelAndView newBill(){
		 return new ModelAndView("billform","command",new Bill());
	}
		 @RequestMapping(value="/savebill",method = RequestMethod.POST)  
		    public ModelAndView savebill(@ModelAttribute("bill") Bill bill , HttpSession session,Principal principal){
			 
			 Double t=(Double)session.getAttribute("total");
			 
			 String id=principal.getName();
			 Users u=usersDao.getUsersById(id);
			 int cart=u.getCart().getCartId();
				List<CartItem>  items=cartItemDao.getCartItemsByCartId(cart);
				
				for(CartItem i:items)
				{
	
					i.setStatus("Y");
					cartItemDao.saveOrUpdate(i);
				}
				
			 bill.setUser(u);
			 bill.setBillAmount(t);
			 bill.setBillDate(new Date(System.currentTimeMillis()));
			 billDao.addBill(bill);
			 
			 return new ModelAndView("redirect:/thanks");
}
		


}
