
 
package com.niit.firstproject.dao;

import java.util.List;

import com.niit.firstproject.model.Cart;
import com.niit.firstproject.model.CartItem;

public interface CartDao {

	public boolean saveOrUpdate(Cart cart);
	
	public boolean delete(Cart cart);
	
	public Cart getCartByUserId(String userId);
	
	
}
