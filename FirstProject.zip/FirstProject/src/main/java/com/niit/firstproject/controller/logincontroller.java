package com.niit.firstproject.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.firstproject.dao.CartItemDao;
import com.niit.firstproject.dao.CategoryDao;
import com.niit.firstproject.model.CartItem;
@Controller
public class logincontroller {
	
	@Autowired
	 CartItemDao cartItemDao;
	@Autowired 
	 CategoryDao categoryDao;	 

	@RequestMapping("/loginpage")  
  public ModelAndView showform(HttpSession session){  
	 ModelAndView mv = new ModelAndView("loginpage");
	 session.setAttribute("categoryList", categoryDao.list());
	 mv.addObject("categoryList", categoryDao.list());
	 return mv;

}
@RequestMapping("/home")  
public ModelAndView index1(Principal principal,HttpSession session){  
	System.out.println("I am in Cart");

	 ModelAndView mv = new ModelAndView("homepage");
    String id = principal.getName();
    session.setAttribute("categoryList", categoryDao.list());
    mv.addObject("categoryList", categoryDao.list());
	 
	 List<CartItem>  list= cartItemDao.getCartItemByUserId(id);
	 
	 System.out.println("size "+list.size());
	
	 if(list==null || list.size()==0)
	 {
		 mv.addObject("size",list.size());
	 }
	 else 
	 {
		 mv.addObject("size",list.size());
	 }
	 return mv;

    
} 

}