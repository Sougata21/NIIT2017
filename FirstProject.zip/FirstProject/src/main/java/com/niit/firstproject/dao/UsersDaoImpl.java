package com.niit.firstproject.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.firstproject.model.Product;
import com.niit.firstproject.model.Users;



@Repository("usersDao")
@Transactional
public class UsersDaoImpl implements UsersDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	protected Session getSession() {
		return sessionFactory.openSession();
	}

	public void addUsers(Users users) {
		// TODO Auto-generated method stub

		Session session = getSession();

		session.save(users);

		session.flush();

		session.close();

	}

	public Users getUsersById(String userId) {
		// TODO Auto-generated method stub
		Session session = getSession();
		
		Query query = session.createQuery("from Users where userId = '"+ userId+"'");
		List<Users> userList = query.list();
        session.close();

		if(userList == null || userList.size()==0)
		{
			return null;
		}
		else
		{
			return userList.get(0);
		}
}
 
	public void updateUsers(Users users) {
		// TODO Auto-generated method stub
		Session session = getSession();

		//String s = users.getUserName();

		session.update(users);

		session.flush();

		session.close();
	}

	public void deleteUsers(String userId) {
		// TODO Auto-generated method stub
		
		Session session = getSession();

		Query query = session.createQuery("from Users where userId = ?"); //select * from Users where userid=1
		query.setString(0, userId);

		Users u=(Users) query.uniqueResult();
		session.delete(u);
		session.flush();

		session.close();
		
	}

	public List<Users> getAllUsers() {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Users");// select * from Users
		List<Users> customerList = query.list();

		return customerList;


	}

	
	
		

	

}
