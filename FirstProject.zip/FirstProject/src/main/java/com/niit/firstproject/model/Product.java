package com.niit.firstproject.model;



import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;



@Entity

public class Product implements Serializable{
	
	@Id
	@GeneratedValue
	private int productId;
	
	private String productName;
	private String productBrand;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category productCategory;
	private double productPrice;
	private String productDiscount;
	private Date productdateAdded;
	private String productImage;
	private String offer;
	private String productDetails;
	private boolean discontinue;
	
	public boolean isDiscontinue() {
		return discontinue;
	}



	public void setDiscontinue(boolean discontinue) {
		this.discontinue = discontinue;
	}



	public String getOffer() {
		return offer;
	}



	public void setOffer(String offer) {
		this.offer = offer;
	}



	public String getProductDetails() {
		return productDetails;
	}



	public void setProductDetails(String productDetails) {
		this.productDetails = productDetails;
	}



	@Transient//Not a column 
	private MultipartFile file;

	


	

	public int getProductId() {
		return productId;
	}



	public void setProductId(int productId) {
		this.productId = productId;
	}



	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getProductBrand() {
		return productBrand;
	}



	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}



	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}



	public void setProductDiscount(String productDiscount) {
		this.productDiscount = productDiscount;
	}



	public Category getProductCategory() {
		return productCategory;
	}



	public void setProductCategory(Category productCategory) {
		this.productCategory = productCategory;
	}


	public double getProductPrice() {
		return productPrice;
	}



	public void setProductprice(double productPrice) {
		this.productPrice = productPrice;
	}



	public String getProductDiscount() {
		return productDiscount;
	}



	public void setProductdiscount(String productDiscount) {
		this.productDiscount = productDiscount;
	}



	public Date getProductdateAdded() {
		return productdateAdded;
	}



	public Date setProductdateAdded(Date productdateAdded) {
		return this.productdateAdded = productdateAdded;
	}
	public MultipartFile getFile() {
		return file;
	}



	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getProductImage() {
		return productImage;
	}



	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}


}

 



