/**
 * 
 */
package com.niit.firstproject.dao;

import java.util.List;

import com.niit.firstproject.model.Cart;
import com.niit.firstproject.model.CartItem;

/**
 * @author Jo
 *
 */
public interface CartItemDao {

	public boolean saveOrUpdate(CartItem cartItem);
	
	public void delete(int cartItemId);
	
	public CartItem get(String cartItemId);
	
	public List<CartItem> getCartItemByUserId(String userId);
	
	public List<CartItem> getCartItemsByCartId(int cart);
}
