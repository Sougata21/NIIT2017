package com.niit.firstproject.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.firstproject.model.Category;
import com.niit.firstproject.model.Product;
import com.niit.firstproject.model.Users;

@Repository("productDao")
@Transactional
public class ProductDaoImpl implements ProductDao{
	
	
	
	
		@Autowired
		private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}
		protected Session getSession() {
			return sessionFactory.openSession();
		}
		


	public List<Product> listcontinueproduct() {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where discontinue = false");
		List<Product> productList = query.list();
        session.close();
		return productList;
	}
	public List<Product> listdiscontinueproduct() {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where discontinue = true");
		List<Product> productList = query.list();
        session.close();
		return productList;
	}

 public List<Product> listByCategoryId(int categoryId) {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where productCategory.categoryId = :categoryId and discontinue = false");
		query.setParameter("categoryId", categoryId);
		List<Product> productList = query.list();
        session.close();
        System.out.println("list "+productList);
		return productList;
	}
	
	public Product listByProductId(int productId) {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where productId = :productId");
		query.setParameter("productId", productId);
		Product product = (Product)query.uniqueResult();//Either one value or null .
        session.close();
        
		return product;
	}
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		Session session = getSession();

		session.save(product);

		session.flush();

		session.close();

	}
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		Session session = getSession();

		

		session.update(product);

		session.flush();

		session.close();

	}
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where productId = ?"); //select * from Users where userid=1
		query.setInteger(0, productId);

		Product p=(Product) query.uniqueResult();
		p.setDiscontinue(true);
		session.update(p);
		session.flush();

		session.close();
		

	}
	public void continueProduct(int productId) {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where productId = ?"); //select * from Users where userid=1
		query.setInteger(0, productId);

		Product p=(Product) query.uniqueResult();
		p.setDiscontinue(false);
		session.update(p);
		session.flush();

		session.close();
		


	}
	public List<Product> listByDiscotinue() {
		// TODO Auto-generated method stub
		Session session = getSession();

		Query query = session.createQuery("from Product where productDiscount between 5 and 20");
		List<Product> productList = query.list();
        session.close();
		return productList;
}
		

}

