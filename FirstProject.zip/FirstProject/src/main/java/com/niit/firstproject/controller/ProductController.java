package com.niit.firstproject.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.security.Principal;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.firstproject.dao.CartItemDao;
import com.niit.firstproject.dao.ProductDao;
import com.niit.firstproject.model.CartItem;
import com.niit.firstproject.model.Product;
@Controller
public class ProductController {
	 @Autowired 
	 ProductDao productDao;
	 @Autowired
	 CartItemDao cartItemDao;
	 
	 @RequestMapping("/productform")  
	    public ModelAndView showform(){  
	        return new ModelAndView("productform","command",new Product());  //command data name request.setAttribute("commnad",new Users();
	    }
	 @RequestMapping("/showProductsByCategory/{categoryId}")  
	    public ModelAndView showProductsByCategory(@PathVariable int categoryId,Principal principal,HttpSession session ){  
		 System.out.println("cat id "+categoryId);
		 ModelAndView mv= new ModelAndView("products");
		 mv.addObject("productList", productDao.listByCategoryId(categoryId));
		 /*String id = principal.getName();
		 List<CartItem>  list= cartItemDao.getCartItemByUserId(id);
   		 
   		 System.out.println("size "+list.size());
   		
   		 if(list==null || list.size()==0)
   		 {
   			
   			 mv.addObject("size",list.size());
   		 }
   		 else 
   		 {
   			
   			 mv.addObject("size",list.size());
   		 }
  		*/ return mv;

	 } 
	 
	 
	 @RequestMapping("/showProduct/{productId}")  
	    public ModelAndView showProduct(@PathVariable int productId,Principal principal,HttpSession session){  
		 ModelAndView mv= new ModelAndView("product");
		 String id = principal.getName();
		 mv.addObject("product", productDao.listByProductId(productId));
		 List<CartItem>  list= cartItemDao.getCartItemByUserId(id);
   		 
   		 System.out.println("size "+list.size());
   		
   		 if(list==null || list.size()==0)
   		 {
   			
   			 mv.addObject("size",list.size());
   		 }
   		 else 
   		 {
   			
   			 mv.addObject("size",list.size());
   		 }
   		
	        return mv;  
	    } 
	 
	 @RequestMapping(value="/saveproduct",method = RequestMethod.POST)  
	    public ModelAndView save(@ModelAttribute("product") Product product ,HttpServletRequest request, //additional parameter
				@RequestParam("file") MultipartFile file){  
	    	
	    	byte fileBytes[];
			FileOutputStream fos = null;
			
			String fileName = "";
			String productImage = "";
			ServletContext context = request.getServletContext();//url of the project
			String realContextPath = context.getRealPath("/");//path of the project
			String p = product.getProductName();
			if (file != null){
				fileName = realContextPath + "/resources/img/" + p + ".jpg";//path of a image in webapp
				productImage = "resources/img/" + p + ".jpg";
				System.out.println("===" + fileName + "===");
				File fileobj = new File(fileName);
				try{
					fos = new FileOutputStream(fileobj);
					fileBytes = file.getBytes();
					fos.write(fileBytes);
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			product.setProductImage(productImage);
			product.setDiscontinue(false);
		    product.setProductdateAdded(new Date(System.currentTimeMillis()));
			productDao.addProduct(product);
	        return new ModelAndView("redirect:/viewproduct");//will redirect to viewusers request mapping  
	    }  
	  //It provides list of users in model object   
	    @RequestMapping("/viewproduct")  
	    public ModelAndView viewproduct(){  
	        List<Product> list=productDao.list();
	        return new ModelAndView("viewproduct","list",list);  //"list" requestattribeut name
	    }  
	   
	    // It displays object data into form for the given id.  
	    // * The @PathVariable puts URL data into variable.  
	    @RequestMapping(value="/editproduct/{id}")  
	    public ModelAndView edit(@PathVariable int id){  
	        Product product = productDao.listByProductId(id);
	        ModelAndView mv=new ModelAndView("editproduct","command",product);  
	        System.out.println(product.getProductName()+"mm"+product.getProductImage());
	        mv.addObject("photo",product.getProductImage());
	        return mv;
	    }
	    
	    // It updates model object.   
	    @RequestMapping(value="/editsaveproduct",method = RequestMethod.POST)  
	    public ModelAndView editsave(@ModelAttribute("product") Product product, HttpServletRequest request, //additional parameter
				@RequestParam("file") MultipartFile file){  
	    	
	    	if(file.getSize()!=0)
	    	{
	    	byte fileBytes[];
			FileOutputStream fos = null;
			String fileName = "";
			String productImage = "";
			ServletContext context = request.getServletContext();//url of the project
			String realContextPath = context.getRealPath("/");//path of the project
			String p = product.getProductName();
			if (file != null){
				fileName = realContextPath + "/resources/img/" + p + ".jpg";//path of a image in webapp
				productImage = "resources/img/" + p + ".jpg";
				System.out.println("===" + fileName + "===");
				File fileobj = new File(fileName);
				try{
					fos = new FileOutputStream(fileobj);
					fileBytes = file.getBytes();
					fos.write(fileBytes);
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			
			product.setProductImage(productImage);
	    	}
			product.setProductdateAdded(new Date(System.currentTimeMillis()));
	    	productDao.updateProduct(product);
	        return new ModelAndView("redirect:/viewproduct");  
	    }  
	    
	     //It deletes record for the given id in URL and redirects to /viewusers   
	    @RequestMapping(value="/deleteproduct/{id}",method = RequestMethod.GET)  
	    public ModelAndView delete(@PathVariable int id){ 
	    	System.out.println("delete is called");
	        productDao.deleteProduct(id);
	        return new ModelAndView("redirect:/viewproduct");  
	    }  
 
	   
	 
}
