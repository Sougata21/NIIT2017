package com.niit.firstproject.dao;



import com.niit.firstproject.model.Bill;

public interface BillDao {
	public void addBill(Bill bill);
	public Bill billbyUserId(String userId);


}
