package com.niit.firstproject.dao;

import java.util.List;

import com.niit.firstproject.model.Category;


public interface CategoryDao {
	public void addCategory(Category category);
	public void updateCategory(Category category);
	public void deleteCategory(int categoryId);
	public Category getCategoryById(int categoryId);

	public List<Category> list();
	
	
	
}
