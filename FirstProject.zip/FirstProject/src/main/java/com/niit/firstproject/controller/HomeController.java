package com.niit.firstproject.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.firstproject.dao.CartItemDao;
import com.niit.firstproject.dao.CategoryDao;
import com.niit.firstproject.dao.ProductDao;
import com.niit.firstproject.model.Cart;
import com.niit.firstproject.model.CartItem;
import com.niit.firstproject.model.Product;

@Controller
public class HomeController {
	@Autowired 
	 ProductDao productDao;
	 @Autowired
	 CartItemDao cartItemDao;
	 @Autowired 
	 CategoryDao categoryDao;	 
	
	@RequestMapping("/manage")  
	    public ModelAndView manage(){  
	        return new ModelAndView("manage");  
	    } 
	 @RequestMapping("/product")  
	    public ModelAndView show(){  
	        return new ModelAndView("product");  
	    } 
	 @RequestMapping("/allproduct")  
	 public ModelAndView allproduct(Principal principal,HttpSession session){  
	        List<Product> List =productDao.listcontinueproduct();
	        ModelAndView mv =new ModelAndView("allproduct","list",List);  //"list" requestattribeut name
	        session.setAttribute("categoryList", categoryDao.list());
	        mv.addObject("categoryList", categoryDao.list());
	        return mv;
	 }
	        @RequestMapping("/403")  
		    public ModelAndView not(){  
		        return new ModelAndView("403");  
		    }
	        @RequestMapping("/thanks")  
		    public ModelAndView thanks(){  
		        return new ModelAndView("thanks");  
		    } 
	        @RequestMapping("/")  
	        public ModelAndView index(HttpSession session){  
	         ModelAndView mv= new ModelAndView("homepage");
	         session.setAttribute("categoryList", categoryDao.list());
	         mv.addObject("categoryList", categoryDao.list());
	            return mv;  
	        } 

	        }  

