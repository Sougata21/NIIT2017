package com.niit.firstproject.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.security.Principal;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.firstproject.dao.CartDao;
import com.niit.firstproject.dao.CartItemDao;
import com.niit.firstproject.dao.UsersDao;
import com.niit.firstproject.model.Cart;
import com.niit.firstproject.model.CartItem;
import com.niit.firstproject.model.Users;

@Controller  
public class UserController {
	 
	  @Autowired 
	  UsersDao usersDao;
	  @Autowired
	  CartDao cartDao;
	  @Autowired
	  CartItemDao cartItemDao;
		 
	  
	  
	@RequestMapping("/usersform")  
    public ModelAndView showform(){  
        return new ModelAndView("usersform","command",new Users());  //command data name request.setAttribute("commnad",new Users();
    } 
	
	 /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/save",method = RequestMethod.POST)  
    public ModelAndView save(@ModelAttribute("users") Users users,HttpServletRequest request, //additional parameter
			@RequestParam("file") MultipartFile file){  
    	
    	String userid=users.getUserId();
		Users temp=usersDao.getUsersById(userid);
		  
		byte fileBytes[];
		FileOutputStream fos = null;
		
		String fileName = "";
		String userImage = "";
		ServletContext context = request.getServletContext();//url of the project
		String realContextPath = context.getRealPath("/");//path of the project
		String un = users.getUserName();
		if (file != null){
			fileName = realContextPath + "/resources/img/" + un + ".jpg";//path of a image in webapp
			userImage = "resources/img/" + un + ".jpg";
			System.out.println("===" + fileName + "===");
			File fileobj = new File(fileName);
			try{
				fos = new FileOutputStream(fileobj);
				fileBytes = file.getBytes();
				fos.write(fileBytes);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		 
		  if(temp!=null)
		  {
			  	ModelAndView  mv= new ModelAndView("usersform","command",users); 
		 		mv.addObject("error", "User Id already exists");
		         return mv;
		  }
			  
			     Cart c=new Cart();
				 cartDao.saveOrUpdate(c);
				 users.setCart(c);
				 users.setEnabled(true);
				 users.setRole("ROLE_USER");
				 users.setUserImage(userImage);
				 usersDao.addUsers(users);
		    	
		    	c.setUser(users);
		  	    cartDao.saveOrUpdate(c);
		  	
    	        return new ModelAndView("redirect:/home");//will redirect to viewusers request mapping
    	      }
		  
    
   
    // It displays object data into form for the given id.  
    // * The @PathVariable puts URL data into variable.  
    @RequestMapping(value="/edituser")  
    public ModelAndView edit(Principal principal){  
    		ModelAndView mv = new ModelAndView("userseditform");
            String id = principal.getName();
   		 		 
            Users users=usersDao.getUsersById(id);
            mv.addObject("photo",users.getUserImage());
            mv.addObject("command",users);
            System.out.println("edit");
          
         List<CartItem>  list= cartItemDao.getCartItemByUserId(id);
        	System.out.println("size "+list.size());
		 
		 if(list==null || list.size()==0)
		 {
			
			 mv.addObject("size",list.size());
		 }
		 else 
		 {
			
			 mv.addObject("size",list.size());
		 }
				 
         
         System.out.println("show");
		 
		 return mv;
    }	
    
   		
    
    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public ModelAndView editsave(@ModelAttribute("users") Users users , HttpServletRequest request, 
			@RequestParam("file") MultipartFile file){  
    	

    	if (file.getSize()!=0)
    	{
    	System.out.println("uiuiuiuiuiuiu"+ file.getSize());
byte fileBytes[];
FileOutputStream fos = null;

String fileName = "";
String userImage = "";
ServletContext context = request.getServletContext();
String realContextPath = context.getRealPath("/");
String un = users.getUserName();
if (file != null){
	System.out.println(" file not null");
fileName = realContextPath + "/resources/img/" + un + ".jpg";
userImage = "resources/img/" + un + ".jpg";
System.out.println("===" + fileName + "===");
File fileobj = new File(fileName);
try{
fos = new FileOutputStream(fileobj);
fileBytes = file.getBytes();
fos.write(fileBytes);
fos.close();
} catch(Exception e) {
e.printStackTrace();
}
}
users.setUserImage(userImage);	
}		
    	String userid=users.getUserId();
    	Cart c= cartDao.getCartByUserId(userid);
    	users.setCart(c);
    	users.setEnabled(true);
		users.setRole("ROLE_USER");
		
		usersDao.updateUsers(users);
		
		return new ModelAndView("redirect:/showuser");  
    
    }  

    
    	
        @RequestMapping(value="/showuser")
    	public ModelAndView showuser(Principal principal){
        	ModelAndView mv = new ModelAndView("showuser");
        	String id = principal.getName();
        	Users users=usersDao.getUsersById(id);
            System.out.println("get");
            if(users==null){
            	System.out.println("NO User");
            	  
            	}
            else{
            	    mv.addObject("user",users);
                    mv.addObject("photo",users.getUserImage());
                    
            }
         
            
           
        	List<CartItem>  list= cartItemDao.getCartItemByUserId(id);
        	System.out.println("size "+list.size());
		 
		 if(list==null || list.size()==0)
		 {
			
			 mv.addObject("size",list.size());
		 }
		 else 
		 {
			
			 mv.addObject("size",list.size());
		 }
				 
         
         System.out.println("show");
		 
		 return mv;
    }
    
    
    
    
    /* It deletes record for the given id in URL and redirects to /viewusers   
    @RequestMapping(value="/deleteusers/{id}",method = RequestMethod.GET)  
    public ModelAndView delete(@PathVariable String id){ 
    	System.out.println("delete is called");
       usersDao.deleteUsers(id);
        return new ModelAndView("redirect:/showuser");  
    }  
   */
    
}