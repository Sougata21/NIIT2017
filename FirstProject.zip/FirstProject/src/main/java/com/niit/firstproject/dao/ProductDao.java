package com.niit.firstproject.dao;

import java.util.List;


import com.niit.firstproject.model.Product;

public interface ProductDao {
	
	public void addProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(int productId);
	public List<Product> list();
	public List<Product> listByCategoryId(int categoryId);
	public Product listByProductId(int productId);
}
